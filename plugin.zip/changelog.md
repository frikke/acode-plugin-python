# Acode Python Plugin Changelog

## 1.1.2

- Updated Pyodide library to 0.28.1

## 1.1.1

- Initial release
