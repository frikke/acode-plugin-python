# acode-plugin-python

Plugin to run python code in [Acode](https://acode.foxdebug.com) editor for android. This plugin uses [Pyodide](https://pyodide.org) project to run python in browser.

## Plugin is underdevelopment

Using this plugin you can run python codes but you cannot import other python files yet, so, this feature will be supportted in future updates.

### Update 1.0.7

- Bugs fixes
- Updated pyodide

### Update 1.1.0

- Bugs fixes
- Reduces waiting time

## WARNING

This is plugin might not be supported in your device. To check weather this plugin is supported in your device or not, open console declare variable using 'const' key word. If it throws a error, your device doesn't support this plugin.
